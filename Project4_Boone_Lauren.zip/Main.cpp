/**************************************************
File: Main.cpp
Name: Lauren Boone
Date: 2/15/19
Description: This is the Main file that runs the 
fanstasy combat game
*************************************************/
#include <iostream>
#include "Game.hpp"


int main() {
	Game game;
	game.gameMenu();
	return 0;
}